"""
🤖 Fraud Detection Model Training Script
Trains the Random Forest model and saves it for the API
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
from imblearn.over_sampling import SMOTE
import joblib
import warnings
import os

warnings.filterwarnings('ignore')

print("=" * 60)
print("🚀 FRAUD DETECTION MODEL TRAINING")
print("=" * 60)

# ============================================================================
# PHASE 1: LOAD DATA
# ============================================================================
print("\n📊 Phase 1: Loading Dataset...")
df = pd.read_csv('dataset_fraud.csv')
print(f"✅ Dataset loaded: {df.shape[0]:,} rows × {df.shape[1]} columns")

# ============================================================================
# PHASE 2: BASIC EDA
# ============================================================================
print("\n📊 Phase 2: Exploratory Data Analysis...")
print(f"   Missing values: {df.isnull().sum().sum()}")
fraud_counts = df['isFraud'].value_counts()
fraud_pct = (fraud_counts[1] / len(df)) * 100
print(f"   Fraud cases: {fraud_counts[1]:,} ({fraud_pct:.2f}%)")
print(f"   Legitimate cases: {fraud_counts[0]:,} ({100-fraud_pct:.2f}%)")
print(f"   ⚠️ Class imbalance ratio: 1:{fraud_counts[0]/fraud_counts[1]:.1f}")

# ============================================================================
# PHASE 3: PREPROCESSING
# ============================================================================
print("\n🔧 Phase 3: Data Preprocessing...")

# Drop unnecessary columns
print("   • Dropping ID columns...")
df_clean = df.drop(['nameOrig', 'nameDest', 'isFlaggedFraud'], axis=1)

# One-hot encode transaction type
print("   • Encoding transaction type...")
df_encoded = pd.get_dummies(df_clean, columns=['type'], drop_first=False)

# Feature engineering
print("   • Engineering features...")
df_encoded['balance_diff_orig'] = df_clean['oldbalanceOrg'] - df_clean['newbalanceOrig']
df_encoded['balance_diff_dest'] = df_clean['newbalanceDest'] - df_clean['oldbalanceDest']
df_encoded['error_balance_orig'] = abs(df_encoded['balance_diff_orig'] - df_clean['amount'])
df_encoded['error_balance_dest'] = abs(df_encoded['balance_diff_dest'] - df_clean['amount'])

# Separate features and target
X = df_encoded.drop('isFraud', axis=1)
y = df_encoded['isFraud']

print(f"   ✅ Features: {X.shape[1]} columns")
print(f"   ✅ Target: {y.shape[0]:,} samples")

# Train-test split
print("   • Splitting train/test (80/20)...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"   ✅ Train: {X_train.shape[0]:,} samples")
print(f"   ✅ Test: {X_test.shape[0]:,} samples")

# ============================================================================
# PHASE 4: HANDLE CLASS IMBALANCE
# ============================================================================
print("\n⚖️ Phase 4: Handling Class Imbalance with SMOTE...")
print(f"   Before SMOTE - Fraud: {y_train.sum():,}, Legitimate: {(y_train==0).sum():,}")

smote = SMOTE(random_state=42)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)

print(f"   After SMOTE - Fraud: {y_train_balanced.sum():,}, Legitimate: {(y_train_balanced==0).sum():,}")
print(f"   ✅ Classes balanced!")

# ============================================================================
# PHASE 5: TRAIN MODEL
# ============================================================================
print("\n🌲 Phase 5: Training Random Forest Model...")
print("   This may take 2-3 minutes...")

model = RandomForestClassifier(
    n_estimators=200,
    max_depth=20,
    min_samples_split=10,
    min_samples_leaf=4,
    random_state=42,
    n_jobs=-1,
    verbose=0
)

model.fit(X_train_balanced, y_train_balanced)
print("   ✅ Training complete!")

# ============================================================================
# PHASE 6: EVALUATE MODEL
# ============================================================================
print("\n📊 Phase 6: Evaluating Model...")

# Predictions
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

# Metrics
print("\n" + "=" * 60)
print("📈 CLASSIFICATION REPORT")
print("=" * 60)
print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Fraud']))

roc_auc = roc_auc_score(y_test, y_proba)
print(f"🎯 ROC-AUC Score: {roc_auc:.4f}")

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("\n📊 Confusion Matrix:")
print(f"   True Negatives:  {cm[0][0]:,}")
print(f"   False Positives: {cm[0][1]:,}")
print(f"   False Negatives: {cm[1][0]:,}")
print(f"   True Positives:  {cm[1][1]:,}")

# Feature Importance
feature_importance = pd.DataFrame({
    'Feature': X.columns,
    'Importance': model.feature_importances_
}).sort_values('Importance', ascending=False).head(5)

print("\n🔝 Top 5 Most Important Features:")
for idx, row in feature_importance.iterrows():
    print(f"   {row['Feature']}: {row['Importance']:.4f}")

# ============================================================================
# PHASE 7: SAVE MODEL
# ============================================================================
print("\n💾 Phase 7: Saving Model...")

# Create models directory if it doesn't exist
os.makedirs('models', exist_ok=True)

# Save model
model_path = 'models/fraud_model.pkl'
joblib.dump(model, model_path)
print(f"   ✅ Model saved to: {model_path}")

# Save feature names
feature_names_path = 'models/feature_names.pkl'
joblib.dump(X.columns.tolist(), feature_names_path)
print(f"   ✅ Feature names saved to: {feature_names_path}")

# ============================================================================
# VERIFICATION
# ============================================================================
print("\n🧪 Phase 8: Verifying Model...")

# Test loading
loaded_model = joblib.load(model_path)
loaded_features = joblib.load(feature_names_path)

# Make a test prediction
test_sample = X_test.iloc[0:1]
test_pred = loaded_model.predict(test_sample)[0]
test_proba = loaded_model.predict_proba(test_sample)[0][1]

print(f"   ✅ Model loaded successfully!")
print(f"   Test prediction: {test_pred} (probability: {test_proba:.4f})")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 60)
print("🎉 TRAINING COMPLETE!")
print("=" * 60)
print(f"✅ Model Type: Random Forest Classifier")
print(f"✅ Training Samples: {X_train_balanced.shape[0]:,}")
print(f"✅ Test Samples: {X_test.shape[0]:,}")
print(f"✅ Features: {X.shape[1]}")
print(f"✅ ROC-AUC Score: {roc_auc:.4f}")
print(f"✅ Model saved: {model_path}")
print(f"\n🚀 Next step: Start the API server!")
print(f"   cd api")
print(f"   uvicorn app:app --reload --port 8000")
print("=" * 60)
