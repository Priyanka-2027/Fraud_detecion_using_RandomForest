import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from pathlib import Path
import os

print("Loading data...")
df = pd.read_csv('dataset_fraud.csv')

# Basic preprocessing
print("Preprocessing data...")
df = df[df['type'].isin(['PAYMENT', 'TRANSFER', 'CASH_OUT', 'CASH_IN', 'DEBIT'])]
df['type'] = LabelEncoder().fit_transform(df['type'])

# Select features and target
X = df[['step', 'type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']]
y = df['isFraud']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
print("Training new model...")
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Create models directory if it doesn't exist
models_dir = Path('models')
models_dir.mkdir(exist_ok=True)

# Save model and feature names
print("Saving model...")
joblib.dump(model, models_dir / 'fraud_model_new.pkl')
joblib.dump(list(X.columns), models_dir / 'feature_names_new.pkl')

# Evaluate
print("\nModel trained successfully!")
print(f"Training accuracy: {model.score(X_train, y_train):.4f}")
print(f"Test accuracy: {model.score(X_test, y_test):.4f}")
print(f"\nModel saved to: {models_dir.absolute()}")
print("\nYou can now update the model paths in api/app.py to use the new model:")
print(f"MODEL_PATH = Path(__file__).parent.parent / 'models' / 'fraud_model_new.pkl'")
print(f"FEATURES_PATH = Path(__file__).parent.parent / 'models' / 'feature_names_new.pkl'")
