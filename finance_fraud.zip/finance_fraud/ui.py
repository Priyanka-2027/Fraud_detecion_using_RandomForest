import streamlit as st
import requests
import pandas as pd
from pydantic import BaseModel

# FastAPI server URL - make sure this matches your FastAPI port
API_URL = "http://localhost:8001"

# Set page config
st.set_page_config(
    page_title="Fraud Detection System",
    page_icon="💳",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main {
        max-width: 1200px;
        padding: 2rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #4CAF50;
        color: white;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 1rem;
    }
    .stButton>button:hover {
        background-color: #45a049;
    }
    .result-box {
        padding: 1.5rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    .fraud {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
    }
    .legit {
        background-color: #e8f5e9;
        border-left: 5px solid #4caf50;
    }
</style>
""", unsafe_allow_html=True)

def main():
    st.title("💳 Fraud Detection System")
    
    with st.sidebar:
        st.header("Transaction Details")
        st.markdown("""
        ### How to Use
        1. Fill in the transaction details
        2. Click 'Check for Fraud'
        3. View the prediction results

        ### Transaction Types
        - **PAYMENT**: Payment transaction
        - **TRANSFER**: Transfer between accounts
        - **CASH_OUT**: Cash withdrawal
        - **CASH_IN**: Cash deposit
        - **DEBIT**: Debit transaction
        """)

    with st.form("transaction_form"):
        st.subheader("Enter Transaction Details")
        col1, col2 = st.columns(2)
        
        with col1:
            step = st.number_input("Step (Time)", min_value=0, value=1, step=1, help="Time step of the transaction")
            amount = st.number_input("Amount", min_value=0.0, value=100.0, format="%.2f", help="Transaction amount")
            type_tx = st.selectbox(
                "Transaction Type",
                ["PAYMENT", "TRANSFER", "CASH_OUT", "CASH_IN", "DEBIT"],
                help="Type of the transaction"
            )
        
        with col2:
            oldbalanceOrg = st.number_input("Old Balance Origin", min_value=0.0, value=1000.0, format="%.2f", help="Balance before transaction")
            newbalanceOrig = st.number_input("New Balance Origin", min_value=0.0, value=900.0, format="%.2f", help="Balance after transaction")
            oldbalanceDest = st.number_input("Old Balance Dest", min_value=0.0, value=0.0, format="%.2f", help="Destination balance before transaction")
            newbalanceDest = st.number_input("New Balance Dest", min_value=0.0, value=100.0, format="%.2f", help="Destination balance after transaction")
        
        submitted = st.form_submit_button("Check for Fraud")
        
        if submitted:
            # Prepare the request data
            transaction_data = {
                "step": int(step),
                "type": type_tx,
                "amount": amount,
                "oldbalanceOrg": oldbalanceOrg,
                "newbalanceOrig": newbalanceOrig,
                "oldbalanceDest": oldbalanceDest,
                "newbalanceDest": newbalanceDest
            }
            
            with st.spinner("Analyzing transaction..."):
                try:
                    # Make API request
                    response = requests.post(f"{API_URL}/predict", json=transaction_data)
                    if response.status_code == 200:
                        result = response.json()
                        
                        # Display results in a nice box
                        result_class = "fraud" if result["is_fraud"] else "legit"
                        st.markdown(f'<div class="result-box {result_class}">', unsafe_allow_html=True)
                        
                        if result["is_fraud"]:
                            st.error("## 🚨 FRAUD DETECTED!")
                        else:
                            st.success("## ✅ LEGITIMATE TRANSACTION")
                        
                        # Create columns for metrics
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Fraud Probability", f"{result['fraud_probability']:.2%}")
                        with col2:
                            st.metric("Risk Level", result['risk_level'])
                        
                        st.write(f"**Message:** {result['message']}")
                        
                        # Show transaction details in an expander
                        with st.expander("View Transaction Details", expanded=False):
                            st.json(transaction_data)
                            
                        st.markdown('</div>', unsafe_allow_html=True)
                        
                        # Add some space
                        st.markdown("<br><br>", unsafe_allow_html=True)
                        
                    else:
                        st.error(f"Error: {response.text}")
                        
                except requests.exceptions.ConnectionError:
                    st.error("⚠️ Could not connect to the API server. Please make sure the FastAPI server is running on port 8001.")
                    st.info("You can start the server by running: `uvicorn api.app:app --reload` in your terminal.")
                    
                except Exception as e:
                    st.error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
