"""
🚨 Financial Fraud Detection API
FastAPI backend for real-time fraud prediction
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import joblib
import pandas as pd
import numpy as np
from pathlib import Path
import warnings

# Initialize FastAPI app
app = FastAPI(
    title="Fraud Detection API",
    description="Real-time financial fraud detection using Machine Learning",
    version="1.0.0"
)

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load trained model and feature names
MODEL_PATH = Path(__file__).parent.parent / "models" / "fraud_model_new.pkl"
FEATURES_PATH = Path(__file__).parent.parent / "models" / "feature_names_new.pkl"

# Load model and feature names
try:
    print("Loading model and features...")
    with open(MODEL_PATH, 'rb') as f:
        model = joblib.load(f)
    with open(FEATURES_PATH, 'rb') as f:
        feature_names = joblib.load(f)
    print("✅ Model and features loaded successfully!")
    print(f"Model type: {type(model).__name__}")
    print(f"Model has predict: {hasattr(model, 'predict')}")
    print(f"Model has predict_proba: {hasattr(model, 'predict_proba')}")
except Exception as e:
    print(f"❌ Error loading model or features: {e}")
    model = None
    feature_names = None


# Request model
class TransactionRequest(BaseModel):
    step: int = Field(..., description="Time step", ge=0)
    type: str = Field(..., description="Transaction type: PAYMENT, TRANSFER, CASH_OUT, CASH_IN, or DEBIT")
    amount: float = Field(..., description="Transaction amount", ge=0)
    oldbalanceOrg: float = Field(..., description="Initial balance before transaction", ge=0)
    newbalanceOrig: float = Field(..., description="New balance after transaction", ge=0)
    oldbalanceDest: float = Field(..., description="Initial recipient balance", ge=0)
    newbalanceDest: float = Field(..., description="New recipient balance", ge=0)

    class Config:
        json_schema_extra = {
            "example": {
                "step": 1,
                "type": "TRANSFER",
                "amount": 181.0,
                "oldbalanceOrg": 181.0,
                "newbalanceOrig": 0.0,
                "oldbalanceDest": 0.0,
                "newbalanceDest": 0.0
            }
        }


# Response model
class PredictionResponse(BaseModel):
    is_fraud: int
    fraud_probability: float
    risk_level: str
    message: str
    transaction_details: dict


def preprocess_transaction(transaction: TransactionRequest) -> pd.DataFrame:
    """
    Preprocess transaction data to match training format
    """
    # Create base dataframe
    data = {
        'step': [transaction.step],
        'amount': [transaction.amount],
        'oldbalanceOrg': [transaction.oldbalanceOrg],
        'newbalanceOrig': [transaction.newbalanceOrig],
        'oldbalanceDest': [transaction.oldbalanceDest],
        'newbalanceDest': [transaction.newbalanceDest]
    }
    
    df = pd.DataFrame(data)
    
    # One-hot encode transaction type
    transaction_types = ['CASH_IN', 'CASH_OUT', 'DEBIT', 'PAYMENT', 'TRANSFER']
    for t_type in transaction_types:
        df[f'type_{t_type}'] = 1 if transaction.type == t_type else 0
    
    # Feature engineering (same as training)
    df['balance_diff_orig'] = transaction.oldbalanceOrg - transaction.newbalanceOrig
    df['balance_diff_dest'] = transaction.newbalanceDest - transaction.oldbalanceDest
    df['error_balance_orig'] = abs(df['balance_diff_orig'] - transaction.amount)
    df['error_balance_dest'] = abs(df['balance_diff_dest'] - transaction.amount)
    
    # Ensure all features are present and in correct order
    for feature in feature_names:
        if feature not in df.columns:
            df[feature] = 0
    
    # Reorder columns to match training
    df = df[feature_names]
    
    return df


def get_risk_level(probability: float) -> str:
    """Determine risk level based on fraud probability"""
    if probability >= 0.8:
        return "CRITICAL"
    elif probability >= 0.6:
        return "HIGH"
    elif probability >= 0.4:
        return "MEDIUM"
    elif probability >= 0.2:
        return "LOW"
    else:
        return "MINIMAL"


def get_message(is_fraud: int, risk_level: str) -> str:
    """Generate user-friendly message"""
    if is_fraud == 1:
        if risk_level == "CRITICAL":
            return "🚨 FRAUD DETECTED - Critical Risk! Transaction should be blocked immediately."
        elif risk_level == "HIGH":
            return "⚠️ FRAUD DETECTED - High Risk! Manual review required."
        else:
            return "⚠️ FRAUD DETECTED - Suspicious transaction detected."
    else:
        if risk_level == "MEDIUM":
            return "⚡ Transaction appears legitimate but shows some unusual patterns."
        else:
            return "✅ Transaction appears legitimate and safe."


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "online",
        "message": "Fraud Detection API is running",
        "model_loaded": model is not None,
        "version": "1.0.0"
    }


@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy" if model is not None else "unhealthy",
        "model_loaded": model is not None,
        "features_loaded": feature_names is not None,
        "feature_count": len(feature_names) if feature_names else 0
    }


@app.get("/stats")
async def get_stats():
    """Get API statistics"""
    return {
        "model_type": "Random Forest Classifier",
        "features_count": len(feature_names) if feature_names else 0,
        "supported_transaction_types": ['PAYMENT', 'TRANSFER', 'CASH_OUT', 'CASH_IN', 'DEBIT'],
        "risk_levels": ["MINIMAL", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    }


@app.post("/predict", response_model=PredictionResponse)
async def predict(transaction: TransactionRequest):
    """
    Predict if a transaction is fraudulent
    """
    if model is None or feature_names is None:
        raise HTTPException(
            status_code=500,
            detail="Model not loaded. Please check the server logs."
        )
    
    try:
        # Convert transaction to DataFrame
        transaction_dict = transaction.dict()
        input_data = pd.DataFrame([transaction_dict])
        
        # Convert categorical 'type' to numerical
        type_mapping = {
            'PAYMENT': 0, 
            'TRANSFER': 1, 
            'CASH_OUT': 2, 
            'CASH_IN': 3, 
            'DEBIT': 4
        }
        input_data['type'] = input_data['type'].map(type_mapping).fillna(-1)
        
        # Make sure all required features are present
        for col in feature_names:
            if col not in input_data.columns:
                input_data[col] = 0
        
        # Reorder columns to match training data
        input_data = input_data[feature_names]
        
        # Make prediction
        try:
            if hasattr(model, 'predict_proba'):
                proba = model.predict_proba(input_data)[0][1]
            else:
                proba = float(model.predict(input_data)[0])
            
            is_fraud = proba >= 0.5
            risk_level = "High" if proba >= 0.7 else "Medium" if proba >= 0.3 else "Low"
            
            return {
                "is_fraud": int(is_fraud),
                "fraud_probability": float(proba),
                "risk_level": risk_level,
                "message": "Potential fraud detected" if is_fraud else "Transaction appears legitimate",
                "transaction_details": transaction_dict
            }
            
        except Exception as e:
            error_msg = f"Prediction failed: {str(e)}"
            if hasattr(model, 'predict'):
                error_msg += f"\nModel type: {type(model).__name__}"
                error_msg += f"\nModel has predict: {hasattr(model, 'predict')}"
                error_msg += f"\nModel has predict_proba: {hasattr(model, 'predict_proba')}"
            raise HTTPException(status_code=500, detail=error_msg)
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Error processing request: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
