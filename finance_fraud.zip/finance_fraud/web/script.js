/**
 * 🚨 FraudGuard AI - Frontend Logic
 * Handles API communication and UI interactions
 */

// Configuration
const API_URL = 'http://localhost:8000';

// DOM Elements
const fraudForm = document.getElementById('fraudForm');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const resultsCard = document.getElementById('resultsCard');
const resultContent = document.getElementById('resultContent');
const apiStatus = document.getElementById('apiStatus');
const apiStatusText = document.getElementById('apiStatusText');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAPIStatus();
    setupEventListeners();
    setupFormValidation();
});

/**
 * Check if API is online
 */
async function checkAPIStatus() {
    try {
        const response = await fetch(`${API_URL}/health`);
        const data = await response.json();
        
        if (data.status === 'healthy') {
            apiStatus.classList.add('online');
            apiStatusText.textContent = 'API Online';
        } else {
            throw new Error('API unhealthy');
        }
    } catch (error) {
        apiStatus.classList.add('offline');
        apiStatusText.textContent = 'API Offline';
        console.error('API Status Check Failed:', error);
    }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    fraudForm.addEventListener('submit', handleSubmit);
    resetBtn.addEventListener('click', handleReset);
    
    // Auto-calculate balances
    const amountInput = document.getElementById('amount');
    const oldBalanceOrig = document.getElementById('oldbalanceOrg');
    const newBalanceOrig = document.getElementById('newbalanceOrig');
    const oldBalanceDest = document.getElementById('oldbalanceDest');
    const newBalanceDest = document.getElementById('newbalanceDest');
    
    amountInput.addEventListener('input', () => {
        const amount = parseFloat(amountInput.value) || 0;
        const oldOrig = parseFloat(oldBalanceOrig.value) || 0;
        const oldDest = parseFloat(oldBalanceDest.value) || 0;
        
        newBalanceOrig.value = Math.max(0, oldOrig - amount).toFixed(2);
        newBalanceDest.value = (oldDest + amount).toFixed(2);
    });
    
    oldBalanceOrig.addEventListener('input', () => {
        const amount = parseFloat(amountInput.value) || 0;
        const oldOrig = parseFloat(oldBalanceOrig.value) || 0;
        newBalanceOrig.value = Math.max(0, oldOrig - amount).toFixed(2);
    });
}

/**
 * Setup form validation
 */
function setupFormValidation() {
    const inputs = fraudForm.querySelectorAll('input[type="number"]');
    
    inputs.forEach(input => {
        input.addEventListener('invalid', (e) => {
            e.preventDefault();
            input.style.borderColor = 'var(--danger)';
        });
        
        input.addEventListener('input', () => {
            input.style.borderColor = '';
        });
    });
}

/**
 * Handle form submission
 */
async function handleSubmit(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(fraudForm);
    const transactionData = {
        step: parseInt(formData.get('step')),
        type: formData.get('type'),
        amount: parseFloat(formData.get('amount')),
        oldbalanceOrg: parseFloat(formData.get('oldbalanceOrg')),
        newbalanceOrig: parseFloat(formData.get('newbalanceOrig')),
        oldbalanceDest: parseFloat(formData.get('oldbalanceDest')),
        newbalanceDest: parseFloat(formData.get('newbalanceDest'))
    };
    
    // Validate
    if (!transactionData.type) {
        showError('Please select a transaction type');
        return;
    }
    
    // Show loading state
    setLoadingState(true);
    
    try {
        // Call API
        const response = await fetch(`${API_URL}/predict`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(transactionData)
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Prediction failed');
        }
        
        const result = await response.json();
        
        // Display results
        displayResults(result);
        
    } catch (error) {
        console.error('Prediction Error:', error);
        showError(error.message || 'Failed to analyze transaction. Please check if the API is running.');
    } finally {
        setLoadingState(false);
    }
}

/**
 * Display prediction results
 */
/**
 * Display prediction results
 */
function displayResults(result) {
    const isFraud = result.is_fraud === 1;
    const probability = (result.fraud_probability * 100).toFixed(2);
    const riskLevel = result.risk_level.toUpperCase();
    
    // Determine color theme based on result
    const themeClass = isFraud ? 'theme-fraud' : 'theme-safe';
    const statusIcon = isFraud ? 
        '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>' : 
        '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';

    const resultHTML = `
        <div class="result-container fade-in ${themeClass}">
            <div class="result-header">
                <div class="result-status-icon">
                    ${statusIcon}
                </div>
                <div class="result-status-text">
                    <h3>${isFraud ? 'FRAUD DETECTED' : 'TRANSACTION SAFE'}</h3>
                    <p>${result.message}</p>
                </div>
            </div>
            
            <div class="result-metrics">
                <div class="metric-card">
                    <span class="metric-label">Fraud Probability</span>
                    <div class="metric-value">${probability}%</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${probability}%"></div>
                    </div>
                </div>
                
                <div class="metric-card">
                    <span class="metric-label">Risk Level</span>
                    <div class="metric-value risk-text">${riskLevel}</div>
                    <span class="metric-sub">Based on ML Model</span>
                </div>
            </div>
            
            <div class="result-details-grid">
                <div class="detail-item">
                    <span class="detail-label">Transaction Type</span>
                    <span class="detail-value">${result.transaction_details.type}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Amount</span>
                    <span class="detail-value">$${result.transaction_details.amount.toLocaleString()}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Time Step</span>
                    <span class="detail-value">${result.transaction_details.step}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Prediction Time</span>
                    <span class="detail-value">0.05s</span>
                </div>
            </div>
            
            <div class="result-actions">
                <button class="btn btn-primary" onclick="scrollToForm()">
                    Analyze Another Transaction
                </button>
            </div>
        </div>
    `;
    
    resultContent.innerHTML = resultHTML;
    resultsCard.style.display = 'block';
    
    // Scroll to results
    setTimeout(() => {
        resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
}

/**
 * Show error message
 */
function showError(message) {
    const errorHTML = `
        <div class="result-container fade-in">
            <div class="result-icon" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
                ⚠️
            </div>
            
            <h3 class="result-title" style="color: var(--warning);">
                Error
            </h3>
            
            <p class="result-message">${message}</p>
            
            <div style="margin-top: 1.5rem;">
                <button class="btn btn-primary" onclick="location.reload()">
                    Retry
                </button>
            </div>
        </div>
    `;
    
    resultContent.innerHTML = errorHTML;
    resultsCard.style.display = 'block';
    
    setTimeout(() => {
        resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
}

/**
 * Set loading state
 */
function setLoadingState(isLoading) {
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoader = submitBtn.querySelector('.btn-loader');
    
    if (isLoading) {
        submitBtn.disabled = true;
        btnText.style.display = 'none';
        btnLoader.style.display = 'block';
    } else {
        submitBtn.disabled = false;
        btnText.style.display = 'block';
        btnLoader.style.display = 'none';
    }
}

/**
 * Handle form reset
 */
function handleReset() {
    fraudForm.reset();
    resultsCard.style.display = 'none';
    
    // Reset to default values
    document.getElementById('step').value = '1';
    document.getElementById('amount').value = '10000';
    document.getElementById('oldbalanceOrg').value = '50000';
    document.getElementById('newbalanceOrig').value = '40000';
    document.getElementById('oldbalanceDest').value = '0';
    document.getElementById('newbalanceDest').value = '10000';
}

/**
 * Scroll to form
 */
function scrollToForm() {
    fraudForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    resultsCard.style.display = 'none';
}

/**
 * Format currency
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

/**
 * Periodic API health check
 */
setInterval(checkAPIStatus, 30000); // Check every 30 seconds
